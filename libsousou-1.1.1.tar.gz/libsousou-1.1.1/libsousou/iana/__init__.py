from libsousou.iana.pen import PrivateEnterpriseNumber
