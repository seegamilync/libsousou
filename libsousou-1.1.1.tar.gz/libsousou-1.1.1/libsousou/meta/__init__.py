from libsousou.meta.hybrid import hybrid_property
